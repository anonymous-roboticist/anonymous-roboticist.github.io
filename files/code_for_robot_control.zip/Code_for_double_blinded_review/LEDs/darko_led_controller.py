#!/usr/bin/env python

''' ---------------------- LEDS ROBOT RBSHERPA ------------------------ '''

import rospy
import numpy as np
from matplotlib import cm
from collections import deque
from geometry_msgs.msg import Twist
from robotnik_signal_msgs.srv import SetSignal, SetSignalRequest, SetSignalResponse
from robotnik_msgs.msg import State, BatteryStatus
from std_msgs.msg import Bool
from jsk_rviz_plugins.msg import OverlayText
from sensor_msgs.msg import Joy

class RobotLeds:

	def __init__(self):

		# Init node
		rospy.init_node('leds_robot_example_node')
		rospy.loginfo("Starting example...")

		# Get name of this node
		self.node_name = rospy.get_name()
		# Get vel topic
		vel_topic_name = rospy.get_param("~cmd_vel_topic", "robotnik_base_control/cmd_vel")
		# Verbose for debug
		self.verbose = rospy.get_param("~verbose", False)

		# Variables for current and last state
		self.last_state = ""
		self.last_state_change_at = rospy.Time(0)
		self.state_filter_queue = deque(maxlen=5)
		self.last_vel_msg_at = rospy.Time(0)
		
		# Variable for velocity threshold
		self.threshold_vel = 0.05
		
		# Variable to save the emergency stop state
		self.emergency_stop = False  # triggered by Robotnik stack. not True if HW estop is pressed!
		self.safety_button_pressed = False  # HW estop

		# Variables to save the current velocity
		self.vel_x = 0
		self.vel_y = 0
		self.vel_z = 0
  
		# Battery status
		self.battery_status = None
		self.last_battery_status_at = rospy.Time(0)
  
		# Create publisher for overlay text, to publish battery status to Rviz
		self.overlay_text_pub = rospy.Publisher('/robot/battery_estimator/overlay_text', OverlayText, queue_size=1)

		# Check if ALS driver service is 
		rospy.loginfo("Waiting driver...")
		rospy.wait_for_service('leds_driver/set_signal')
		self.send_led_command = rospy.ServiceProxy('leds_driver/set_signal', SetSignal)

		# Wait for rcomponent ready driver
		rospy.loginfo("Waiting rcomponent...")
		rospy.wait_for_message('leds_driver/state', State)

		# LED Mute implementation
		self.prev_buttons = None 
		self.LED_Mute_On = False

		# Defining individual Buttons for input
		self.L2_BUTTON = 6          # change if your mapping is different
		self.OPTIONS_BTN = 9
		self.L1_BUTTON = 4
		self.R2_BUTTON = 7
		self.BG_BUTTON = 13

		self.SQ_BUTTON = 0
		self.XX_BUTTON = 1          # change if your mapping is different
		self.OO_BUTTON = 2
		self.TR_BUTTON = 3		

		self.joy_buttons = []       # will store the last /robot/joy array
		rospy.Subscriber("/robot/joy", Joy, self.cbJoy)

		# Subscribe to vel robot
		rospy.Subscriber(vel_topic_name, Twist, self.vel_callaback, queue_size=1)

		# Subscribe to emergency_stop
		rospy.Subscriber("robotnik_base_hw/emergency_stop", Bool, self.emergency_stop_callaback, queue_size=1)
		rospy.Subscriber("/robot/safety_module/emergency_stop", Bool, self.safety_button_pressed_callback, queue_size=1)

		# Subscribe to battery status
		rospy.Subscriber("/robot/battery_estimator/data", BatteryStatus, self.battery_status_callback, queue_size=1)
  
		# Timeout for first emergency stop msg
		rospy.sleep(1)

		rospy.loginfo("Running example!")


	def vel_callaback(self, msg):
		self.last_vel_msg_at = rospy.Time.now()
		self.vel_x = msg.linear.x
		self.vel_y = msg.linear.y
		self.vel_z = msg.angular.z

	def emergency_stop_callaback (self, msg):
		self.emergency_stop = msg.data

	def safety_button_pressed_callback (self, msg):
		self.safety_button_pressed = msg.data
  
	def battery_status_callback(self, msg):
		self.battery_status = msg
		self.last_battery_status_at = rospy.Time.now()

	def cbJoy(self, msg):
		
		if self.prev_buttons is None:
			self.prev_buttons = msg.buttons
			return

		self.joy_buttons = msg.buttons
		
		if self.prev_buttons[self.OPTIONS_BTN] == 1 and msg.buttons[self.OPTIONS_BTN] == 0: self.LED_Mute_On = not(self.LED_Mute_On)

		self.prev_buttons = msg.buttons

	def getRobotState(self):
		if (rospy.Time.now() - self.last_vel_msg_at) < rospy.Duration(0.5):
			vel_x = self.vel_x
			vel_y = self.vel_y
			vel_z = self.vel_z
		else:
			vel_x = vel_y = vel_z = 0

		vel = self.threshold_vel
  
		# Default state: Robot is stopped (green LEDs)
		state = "stop_robot"
  
		# Priority 1: Critical battery status
		if self.battery_status is not None:
			if not self.battery_status.is_charging and (self.battery_status.level < 65 or self.battery_status.time_remaining < 60):
				return "battery_critical"

		# Priority 2: E-stop / safety stop active
		if self.emergency_stop or self.safety_button_pressed:
			return "safety_stop_button" if self.safety_button_pressed else "emergency_stop"

		# Priority 3: Charging
		if self.battery_status is not None and self.battery_status.is_charging:
			return "battery_charging"

		if self.LED_Mute_On:
			return "led_mute"
		else:
			# If a trigger is *currently* pressed, override everything below
			if len(self.joy_buttons) > max(self.L2_BUTTON, self.R2_BUTTON):
				if self.joy_buttons[self.SQ_BUTTON]:
					return "turn_left_forward"     # helper will mirror to rear
				# elif self.joy_buttons[self.R2_BUTTON]:
				# 	return "turn_right_forward"
				# elif self.joy_buttons[self.BG_BUTTON]:
				# 	return "stop_robot"		
				elif self.joy_buttons[self.OO_BUTTON]:
					return "attention_request"
				elif self.joy_buttons[self.TR_BUTTON]:
					return "turn_right_forward"
				# elif self.joy_buttons[self.SQ_BUTTON]:
				# 	return "battery_critical"
				elif self.joy_buttons[self.XX_BUTTON]:
					return "safety_stop_button"			

		# Check direction
		if vel_x < -0.05:
			direction = False
		else:
			direction = True


		if abs(vel_y) > vel:

			# Right shift
			if vel_y > vel:

				state = "omni_left"

			# Left shift
			elif vel_y < -vel:

				state = "omni_right"

		elif abs(vel_z) > vel:

			# Forward turning
			if direction:

				if vel_z > vel:

					state = "turn_left_forward"

				elif vel_z < -vel:

					state = "turn_right_forward"

			# Backward turning
			else:

				if vel_z > vel:

					state = "turn_right_forward"  # when driving backwards, we swap the direction

				elif vel_z < -vel:

					state = "turn_left_forward"  # when driving backwards, we swap the direction

		else:

			# Only forward
			if vel_x > vel:

				state = "forward"

			# Only backward
			elif vel_x < -vel:

				state = "backward"

			else:

				state = "stop_robot"

		return state


	def setLedState(self, signal):
		res = SetSignalResponse()
		command = SetSignalRequest()

		command.signal_id =	signal
		command.enable = True
		res = self.send_led_command(command)
		if self.verbose == True:
			rospy.loginfo(res.ret.message)

	def clearLedState(self, signal):
		res = SetSignalResponse()
		command = SetSignalRequest()

		command.signal_id =	signal
		command.enable = False
		res = self.send_led_command(command)
		
		if self.verbose == True:
			rospy.loginfo(res.ret.message)

	def set_turn_indicator_also_in_other_direction(self, state, clear=False):
		other_dir = state.replace("_backward", "_forward") if state.endswith("_backward") else state.replace("_forward", "_backward")
		if clear:
			self.clearLedState(other_dir)
		else:
			self.setLedState(other_dir)
		rospy.loginfo("Since this is a turn signal, I also " + ("clear" if clear else "sent") + " on the other direction: " + other_dir)
	
	def filter_most_frequent_state(self, updated_state):
		self.state_filter_queue.appendleft(updated_state)
		
		counting_dict = {}
		highest_count = -1
		most_frequent_state = ""
		for state in reversed(self.state_filter_queue):  # backwards such that more recent states in front can take precedence if they have equal count
			if not state in counting_dict: counting_dict[state] = 0
			counting_dict[state] += 1
   
			if counting_dict[state] >= highest_count:
				most_frequent_state = state
				highest_count = counting_dict[state]
   
		return most_frequent_state

	def publish_battery_status_text_to_rviz(self):
		# Publish battery status to Rviz overlay text
		if (
			self.battery_status.level is not None
			and rospy.Time.now() - self.last_battery_status_at < rospy.Duration(5.0)
		):
			battery_level = self.battery_status.level
		else:
			battery_level = float("nan")
		
		overlay_text = OverlayText()
		if np.isfinite(battery_level):
			#battery_level = 60
			overlay_text.text = "Battery Level: {:.1f}%".format(battery_level)
			if self.battery_status.is_charging:
				overlay_text.text += " (Charging)"
			if battery_level < 65:
				overlay_text.text += " CRITICALLY LOW!"
		else:
			overlay_text.text = "Battery Level: N/A"
   
		overlay_text.action = OverlayText.ADD
		overlay_text.left = 10
		overlay_text.top = 10
		overlay_text.width = 1000
		overlay_text.height = 128
		overlay_text.text_size = 12
		overlay_text.fg_color.a = 1.0
  
		# Set color based on battery level using a colormap from green over yellow to red, e.g. using the left part of the gist_rainbow colormap up to around 0.4
		if np.isfinite(battery_level):
			cmap = cm.get_cmap('gist_rainbow', 256)  # Get a colormap
			min_threshold = 60.0  # Below this value, we start to go to red
			color_value = np.clip((battery_level - min_threshold) / (100.0 - min_threshold), 0.0, 1.0) * 0.5  # Normalize to [0, 1], then to [0, 0.5] since green is in the middle and red is at 0.0
			color = cmap(color_value)[:3]  # Get RGB values from colormap, ignoring alpha channel
	
			overlay_text.fg_color.r = color[0]
			overlay_text.fg_color.g = color[1]
			overlay_text.fg_color.b = color[2]
		else:
			# Set magenta color
			overlay_text.fg_color.r = 1.0
			overlay_text.fg_color.g = 0.0
			overlay_text.fg_color.b = 1.0	
  
		self.overlay_text_pub.publish(overlay_text)
			
	def run(self):
		updated_state = self.getRobotState()
		most_frequent_state = self.filter_most_frequent_state(updated_state)
		
		now = rospy.Time.now()
		dt_since_last_state_change = now.to_sec() - self.last_state_change_at.to_sec()
  
		# Publish battery status to Rviz overlay text
		self.publish_battery_status_text_to_rviz()

		if most_frequent_state and most_frequent_state != self.last_state and dt_since_last_state_change > 0.5:
			# Clear old animation
			self.clearLedState(self.last_state)
			if self.verbose == True: rospy.loginfo("I deactivate: " + self.last_state)
			if "turn_" in self.last_state: self.set_turn_indicator_also_in_other_direction(self.last_state, clear=True) # Hack to show turn indicator pointing to the same side in both front and rear
			
			# Set green background before all other regular signals
			if not "emergency" in most_frequent_state and not "safety" in most_frequent_state and not "battery" in most_frequent_state:
				self.setLedState("green_background")
				if self.verbose == True:  rospy.loginfo("I send signal: " + most_frequent_state)
			
			# Set the actual state
			self.setLedState(most_frequent_state)
			if self.verbose == True:  rospy.loginfo("I send signal: " + most_frequent_state)

			# Hack to show turn indicator pointing to the same side in both front and rear
			if "turn_" in most_frequent_state: self.set_turn_indicator_also_in_other_direction(most_frequent_state)

			# Hack to show green background while turning
			if "turn_left" in most_frequent_state or "turn_right" in most_frequent_state or most_frequent_state in ("forward", "backward"):
				# Hack because shift effect resets everything to black somehow
				self.setLedState("green_background_on_sides")
				rospy.loginfo("Keeping green background on both sides on")

			# Store new last state
			self.last_state = most_frequent_state
			self.last_state_change_at = now

def main():
	
	robot_leds = RobotLeds()
	r = rospy.Rate(10)

	while not rospy.is_shutdown():
		robot_leds.run()
		r.sleep()

if __name__ == '__main__':
	try:
		main()
	except rospy.ROSInterruptException:
		pass
