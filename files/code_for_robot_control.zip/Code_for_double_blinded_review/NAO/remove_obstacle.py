#!/usr/bin/env python3
import qi
import time
import sys

# ------------ CONFIGURATION ------------
IP = "192.168.0.105"  # Robot IP
PORT = 9559

SPEECH = True
USE_LEDS = False  # <<< Toggle this to enable or disable LED effects

# ------------ CONSTANTS ------------
POINT_TARGET = [0.8, 0.0, -0.2]  # 80 cm ahead
POINT_SPEED = 0.4
EYE_PULSE_HZ = 1.5
PULSE_SECONDS = 3.0

# Slight deictic raise pose (natural halflift)
RAISE_POSE = [0.3, 0.1, -1.2, -0.6, 0.0, 1.0]  # LShoulderPitch, LShoulderRoll, ...
LEFT_ARM_CHAIN = [
    "LShoulderPitch", "LShoulderRoll",
    "LElbowYaw", "LElbowRoll",
    "LWristYaw", "LHand"
]

NEUTRAL_NAMES = [
    "LElbowRoll", "LElbowYaw", "LHand", "LShoulderPitch", "LShoulderRoll", "LWristYaw",
    "RElbowRoll", "RElbowYaw", "RHand", "RShoulderPitch", "RShoulderRoll", "RWristYaw"
]
NEUTRAL_KEYS = [
    -1.0, -0.4, 0.3, 1.0, 0.3, 0.0,
     1.0, 0.4, 0.3, 1.0, -0.3, 0.0
]

# ------------ GLOBAL PROXIES (set in main) ------------
motion = None
leds = None
tts = None
tracker = None

# ------------ HELPERS -------------

def blink_eyes_fast(leds, blinks=4, interval=0.2):
    if USE_LEDS:
        for _ in range(blinks):
            leds.fadeRGB("FaceLeds", 0xff0000, 0.05)
            time.sleep(interval)
            leds.fadeRGB("FaceLeds", 0x000000, 0.05)
            time.sleep(interval)

def eyes_neutral():
    if USE_LEDS:
    # leds.fadeRGB("FaceLeds", 0x000000, 0.2) # Off
        leds.fadeRGB("FaceLeds",0x111111, 1) # Neutral
        leds.setIntensity("FaceLeds", 1)

def eye_contact():
    # Choregraphe simplified export in Python.

    names = list()
    times = list()
    keys = list()

    names.append("HeadPitch")
    times.append([0.3])
    keys.append([0.292952])

    names.append("HeadYaw")
    times.append([0.3])
    keys.append([-0.245482])

    motion.angleInterpolation(names, keys, times, True)


# def eyes_pulse_red(duration=PULSE_SECONDS, hz=EYE_PULSE_HZ):
#     if not USE_LEDS:
#         return
#     period = 1.0 / hz
#     end_t = time.time() + duration
#     while time.time() < end_t:
#         leds.fadeRGB("FaceLeds", 0xff0000, period / 2.0)
#         time.sleep(period / 2.0)
#         leds.fadeRGB("FaceLeds", 0x000000, period / 2.0)
#         time.sleep(period / 2.0)

def raise_arm():
    motion.setStiffnesses("LArm", 1.0)
    motion.angleInterpolationWithSpeed(LEFT_ARM_CHAIN, RAISE_POSE, 0.25)

def point_ahead():
    tracker.pointAt("LArm", POINT_TARGET, 0, POINT_SPEED)  # 0 = FRAME_TORSO

def reset_pose():
    motion.angleInterpolationWithSpeed(NEUTRAL_NAMES, NEUTRAL_KEYS, 0.2)
    if USE_LEDS:
        leds.fadeRGB("FaceLeds",0x111111, 1) # Neutral
        leds.setIntensity("FaceLeds", 1)
    motion.setStiffnesses("LArm", 0.0)

def face_seen(timeout=1.0):
    time.sleep(timeout)
    return False  # Placeholder

# ------------ MAIN BEHAVIOR ------------

def announce_stuck():
    # 1. Center head and pulse eyes
    motion.setStiffnesses("Head", 1.0)
    motion.angleInterpolationWithSpeed("HeadYaw", 0.0, 0.25)
    motion.setStiffnesses("Head", 0.0)
    blink_eyes_fast(leds)

    eyes_neutral()
    # 2. Slight deictic arm raise
    raise_arm()

    # 2.1 Look slightly down to reinforce pointing gesture
    motion.setStiffnesses("Head", 1.0)
    motion.angleInterpolationWithSpeed("HeadPitch", 0.45, 0.25)  # 0.3 rad ≈ 17°

    # 3. Speak request
    if SPEECH:
        tts.say("The way is blocked. Please clear the obstacle in front of me!")

    # 4. Full point at obstacle
    point_ahead()

    # 5. Escalate if still ignored
    eye_contact()
    if not face_seen(1.0):
        if USE_LEDS:
            leds.fadeRGB("FaceLeds", 0xff0000, 0.2)
        if SPEECH:
            tts.say("I cannot move until the way is clear.")

    time.sleep(1.5)

    # 6. Reset
    reset_pose()

    # motion.angleInterpolationWithSpeed(["HeadYaw", "HeadPitch"], [0.0, 0.0], 0.2)
    motion.setStiffnesses("Head", 0.0)

# ------------ ENTRY POINT ------------

def main():
    global motion, leds, tts, tracker

    app = qi.Application(["StuckAnnouncement", "--qi-url=tcp://{}:{}".format(IP, PORT)])
    app.start()
    session = app.session

    # Initialize proxies
    motion = session.service("ALMotion")
    tts = session.service("ALTextToSpeech")
    tracker = session.service("ALTracker")
    leds = session.service("ALLeds") if USE_LEDS else None

    announce_stuck()

if __name__ == "__main__":
    main()
