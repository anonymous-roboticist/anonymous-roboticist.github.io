#!/usr/bin/env python3
import qi
import time
import sys

# ------------------ CONFIG ------------------
IP = "192.168.0.105"  # Robot IP
PORT = 9559

SPEECH = True
USE_LEDS = False  # <<< Toggle this to enable or disable LED effects

SPEED_FRACTION = 0.2          # Safe reset speed for neutral pose
YAW_LEFT = 0.6                # rad (~34 deg)
GLANCE_HOLD = 0.9             # seconds
POINT_TARGET = [1.0, 1.2, 0.0]  # x, y, z in torso frame (metres)
POINT_SPEED = 0.5             # 0..1 fraction for ALTracker.pointAt

# ------------ GLOBAL PROXIES (set in main) ------------
motion = None
leds = None
tts = None
tracker = None

# ------------ POSES --------------
NEUTRAL_NAMES = [
    "LElbowRoll", "LElbowYaw", "LHand", "LShoulderPitch", "LShoulderRoll", "LWristYaw",
    "RElbowRoll", "RElbowYaw", "RHand", "RShoulderPitch", "RShoulderRoll", "RWristYaw"
]
NEUTRAL_KEYS = [
    -1.1658, -0.443368, 0.258, 0.908086, 0.302156, -0.047596,
     1.23491,  0.498508, 0.288, 0.955724, -0.297638, -0.016916
]

# ------------ LED HELPERS ------------

def eye_gaze_left():
    """Set eye LEDs so the left ones are brighter (cyan) and right ones dim (blue)."""
    if USE_LEDS:
        leds.fadeRGB("LeftFaceLeds", 0x00ffff, 0.2)
        leds.fadeRGB("RightFaceLeds", 0x000000, 0.2)

def eye_neutral():
    """Soft white idle glow instead of full off."""
    if USE_LEDS:
        leds.fadeRGB("FaceLeds",0x111111, 1) # Neutral
        leds.setIntensity("FaceLeds", 1)


def eye_off():
    """Turn off eye LEDs."""
    if USE_LEDS:
        leds.fadeRGB("FaceLeds", 0x000000, 0.2)

# ------------ HELPERS ------------

def go_neutral():
    """Return both arms to neutral key frame."""
    motion.angleInterpolationWithSpeed(NEUTRAL_NAMES, NEUTRAL_KEYS, SPEED_FRACTION)

def glance_left():
    """Head glance to the left."""
    motion.setStiffnesses("Head", 1.0)
    motion.angleInterpolationWithSpeed("HeadYaw", YAW_LEFT, 0.25)
    time.sleep(GLANCE_HOLD)
    motion.angleInterpolationWithSpeed("HeadYaw", 0.0, 0.25)
    motion.setStiffnesses("Head", 0.0)

def point_left():
    """Use ALTracker.pointAt with left arm toward POINT_TARGET in torso frame."""
    motion.setStiffnesses("LArm", 1.0)
    tracker.pointAt("LArm", POINT_TARGET, 0, POINT_SPEED)  # 0 = FRAME_TORSO

def arm_down():
    go_neutral()
    motion.setStiffnesses("LArm", 0.0)

def face_seen(timeout=1.0):
    time.sleep(timeout)
    return False

# ------------ MAIN BEHAVIOR ------------

def broadcast_left_turn():
    glance_left()
    tts.say("Turning left.")
    eye_gaze_left()
    point_left()

    time.sleep(1.0)
    arm_down()
    eye_neutral()

# ------------ ENTRY POINT ------------

def main():
    global motion, leds, tts, tracker

    app = qi.Application(["LeftTurnCue", "--qi-url=tcp://{}:{}".format(IP, PORT)])
    app.start()
    session = app.session

    # Initialize services
    motion  = session.service("ALMotion")
    tts     = session.service("ALTextToSpeech")
    tracker = session.service("ALTracker")
    leds    = session.service("ALLeds") if USE_LEDS else None

    try:
        broadcast_left_turn()
    except KeyboardInterrupt:
        arm_down()
        eye_off()
        print("Interrupted - arms reset to neutral.")

if __name__ == "__main__":
    main()
