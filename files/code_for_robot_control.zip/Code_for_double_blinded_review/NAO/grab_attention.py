#!/usr/bin/env python3
import qi
import time
import sys

IP = "192.168.0.105"  # Robot IP
PORT = 9559

USE_LEDS = True

def blink_eyes_white_fast(leds, blinks=4, interval=0.2):
    for _ in range(blinks):
        leds.fadeRGB("FaceLeds", 0xFFFFFF, 0.05)
        time.sleep(interval)
        leds.fadeRGB("FaceLeds", 0x000000, 0.05)
        time.sleep(interval)

    eyes_neutral(leds)

def eyes_neutral(leds):
    if USE_LEDS:
    # leds.fadeRGB("FaceLeds", 0x000000, 0.2) # Off
        leds.fadeRGB("FaceLeds",0x111111, 0.2) # Neutral
        leds.setIntensity("FaceLeds", 1)

def main():
    try:
        app = qi.Application(["RobotScript", "--qi-url=tcp://{}:{}".format(IP, PORT)])
        app.start()
        session = app.session

        global USE_LEDS

        # Create proxies
        motion = session.service("ALMotion")
        leds   = session.service("ALLeds")
        tts    = session.service("ALTextToSpeech")

        def look(yaw, speed=0.3):
            motion.setAngles("HeadYaw", yaw, speed)

        def go_neutral():
            """Move both arms to a neutral pose."""
            NEUTRAL_NAMES = [
                "LElbowRoll","LElbowYaw","LHand","LShoulderPitch","LShoulderRoll","LWristYaw",
                "RElbowRoll","RElbowYaw","RHand","RShoulderPitch","RShoulderRoll","RWristYaw"
            ]
            NEUTRAL_KEYS  = [
                -1.1658, -0.443368, 0.258, 0.908086, 0.302156, -0.047596,
                1.23491,  0.498508, 0.288, 0.955724, -0.297638, -0.016916
            ]
            NEUTRAL_TIME  = 0.6

            motion.angleInterpolation(
                NEUTRAL_NAMES,
                [[k] for k in NEUTRAL_KEYS],
                [[NEUTRAL_TIME]] * len(NEUTRAL_NAMES),
                True
            )

        def wave(strokes=3):
            """Lift arm, wave <strokes> times, then lower arm to neutral."""
            R_ARM = ["RShoulderPitch", "RShoulderRoll",
                     "RElbowYaw", "RElbowRoll", "RWristYaw", "RHand"]

            motion.setStiffnesses("RArm", 1.0)

            lift = [-1.0, -0.2, 1.2, 1.5, 0.0, 0.0]
            motion.angleInterpolationWithSpeed(R_ARM, lift, 0.35)

            for _ in range(strokes):
                motion.setAngles("RElbowRoll", 0.3, 0.6)
                time.sleep(0.3)
                motion.setAngles("RElbowRoll", 1.5, 0.6)
                time.sleep(0.3)

            go_neutral()
            motion.setStiffnesses("RArm", 0.0)

        def wave_lr(strokes=3):
            """Perform a side-to-side wave using concrete joint values."""
            motion.setStiffnesses("RArm", 1.0)

            # Define joint names for consistency
            R_ARM_JOINTS = [
                "RElbowRoll", "RElbowYaw", "RHand",
                "RShoulderPitch", "RShoulderRoll", "RWristYaw"
            ]

            # Initial raise pose (arm lifted, ready to wave)
            raise_pose = [
                0.96953, 1.41891, 0.2808,
            -0.728608, -0.598302, -0.190258
            ]

            # First endpoint (wave left)
            left_pose = [
                0.682672, 1.79627, 0.0192,
            -0.16563, -0.645856, -0.153442
            ]

            # Second endpoint (wave right)
            right_pose = [
                0.763974, 0.285282, 0.0192,
            -0.48777, 0.228524, -0.16418
            ]

            # Raise the arm
            motion.angleInterpolationWithSpeed(R_ARM_JOINTS, raise_pose, 0.6)

            # Wave side-to-side
            for _ in range(strokes):
                motion.angleInterpolationWithSpeed(R_ARM_JOINTS, left_pose, 0.8)
                motion.angleInterpolationWithSpeed(R_ARM_JOINTS, right_pose, 0.8)

            # Return to neutral
            go_neutral()
            motion.setStiffnesses("RArm", 0.0)

        def glance_left_then_forward(yaw=0.6, hold=0.8):
            """Look left, hold, then forward."""
            motion.setAngles("HeadYaw", yaw, 0.3)
            time.sleep(hold)
            motion.setAngles("HeadYaw", 0.0, 0.3)

        # --- Execution sequence ---
        #glance_left_then_forward()
        if USE_LEDS:
            blink_eyes_white_fast(leds)
        tts.say("\\vol=65\\\\rspd=80\\ Excuse me ...")
        wave()

        time.sleep(1.3)
        # if USE_LEDS:
        #     leds.fadeRGB("FaceLeds", 0x00FF00, 0.3)        # green
        # tts.say("Thank you for your attention!")

        # time.sleep(0.4)
        if USE_LEDS:
            leds.fadeRGB("FaceLeds", 0xFF0000, 0.2)        # red
        tts.say("\\vol=90\\\\rspd=85\\ I need assistance!")

        # Turn off face LEDs
        leds.fadeRGB("FaceLeds",0x111111, 1) # Neutral
        leds.setIntensity("FaceLeds", 1)

    except Exception as e:
        print("Error:", e)
        sys.exit(1)

if __name__ == "__main__":
    main()
