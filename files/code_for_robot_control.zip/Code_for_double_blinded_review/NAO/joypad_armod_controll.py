#!/usr/bin/env python3
"""
Mapping of buttons of PS4 Controller
------------------------
  Square    (index 0) -> armod_attention_grab.py
  X         (index 1) -> armod_obst_remove.py
  O / Circle(index 2) -> armod_indicates_move.py
  Triangle  (index 3) -> no action

Adjust the BUTTON_ACTIONS table if you need different assignments.
"""

import rospy
import subprocess
from sensor_msgs.msg import Joy

# mapping button index -> (name, script to run or None)
BUTTON_ACTIONS = {
    0: ("Square",   "grab_attention.py"),
    1: ("X",        "error_indication.py"),
    2: ("O",        "indicate_turn.py"),
    3: ("Triangle", "remove_obstacle.py"),  # no script assigned
}

# track previous button states (buttons 0-3)
prev_state = [0, 0, 0, 0]

def launch_script(script_path: str):
    """Run a Python 3 script in the background."""
    rospy.loginfo("Launching {} with python3 ...".format(script_path))
    subprocess.Popen(
        ["python3", script_path],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.STDOUT,
    )


def joy_cb(msg: Joy):
    global prev_state
    for idx, curr in enumerate(msg.buttons[:4]):  # only buttons 0-3
        if curr and not prev_state[idx]:          # rising edge (0 -> 1)
            name, script = BUTTON_ACTIONS[idx]
            rospy.loginfo("{} pressed -- starting script".format(name))
            if script:
                launch_script(script)
            else:
                rospy.loginfo("No script assigned to this button.")
        prev_state[idx] = curr

def main():
    rospy.init_node("gamepad_script_launcher")
    rospy.Subscriber("robot/joy", Joy, joy_cb, queue_size=10)
    rospy.loginfo("Ready. Listening on /robot/joy ...")
    rospy.spin()

if __name__ == "__main__":
    main()
