#!/usr/bin/env python3
import qi
import time
import sys

USE_LEDS = False

def go_to_armrest(motion):
    
    # for eff in ("LArm", "RArm"):
    #     self._motion.killMove(eff)

    time_scaler = 2

    names = list()
    times = list()
    keys = list()

    names.append("HeadPitch")
    times.append([0.12*time_scaler])
    keys.append([0.154892])

    names.append("HeadYaw")
    times.append([0.12*time_scaler])
    keys.append([0.0383081])

    names.append("LElbowRoll")
    times.append([0.16*time_scaler])
    keys.append([-1.20455])

    names.append("LElbowYaw")
    times.append([0.16*time_scaler])
    keys.append([-0.449198])

    names.append("LHand")
    times.append([0.16*time_scaler])
    keys.append([0.2976])

    names.append("LShoulderPitch")
    times.append([0.16*time_scaler])
    keys.append([0.845811])

    names.append("LShoulderRoll")
    times.append([0.16*time_scaler])
    keys.append([0.269631])

    names.append("LWristYaw")
    times.append([0.16*time_scaler])
    keys.append([0.0331883])

    names.append("RElbowRoll")
    times.append([0.16*time_scaler])
    keys.append([1.26084])

    names.append("RElbowYaw")
    times.append([0.16*time_scaler])
    keys.append([0.51476])

    names.append("RHand")
    times.append([0.16*time_scaler])
    keys.append([0.3016])

    names.append("RShoulderPitch")
    times.append([0.16*time_scaler])
    keys.append([0.906394])

    names.append("RShoulderRoll")
    times.append([0.16*time_scaler])
    keys.append([-0.304133])

    names.append("RWristYaw")
    times.append([0.16*time_scaler])
    keys.append([-0.0249198])

    motion.angleInterpolation(names, keys, times, True)

def cross_arms(motion):
    # Choregraphe simplified export in Python.
    names = list()
    times = list()
    keys = list()

    time_scaler = 5

    names.append("LElbowRoll")
    times.append([0.08*time_scaler])
    keys.append([-1.38363])

    names.append("LElbowYaw")
    times.append([0.08*time_scaler])
    keys.append([-0.836072])

    names.append("LHand")
    times.append([0.08*time_scaler])
    keys.append([0.0224])

    names.append("LShoulderPitch")
    times.append([0.08*time_scaler])
    keys.append([0.592082])

    names.append("LShoulderRoll")
    times.append([0.08*time_scaler])
    keys.append([-0.311444])

    names.append("LWristYaw")
    times.append([0.08*time_scaler])
    keys.append([1.8515])

    names.append("RElbowRoll")
    times.append([0.08])
    keys.append([0.796188])

    names.append("RElbowYaw")
    times.append([0.08*time_scaler])
    keys.append([0.839056])

    names.append("RHand")
    times.append([0.08*time_scaler])
    keys.append([0.0204])

    names.append("RShoulderPitch")
    times.append([0.08*time_scaler])
    keys.append([0.658128])

    names.append("RShoulderRoll")
    times.append([0.08*time_scaler])
    keys.append([0.3267])

    names.append("RWristYaw")
    times.append([0.08*time_scaler])
    keys.append([-1.85465])

    motion.angleInterpolation(names, keys, times, True)

def shake_head(motion, speed=0.3, repetitions=3):
    """
    Makes the NAO shake its head side to side.

    :param motion: ALMotion proxy
    :param speed: Time (in seconds) between shakes
    :param repetitions: Number of left-right shakes
    """
    # Ensure the head has stiffness
    motion.setStiffnesses("Head", 1.0)

    # Define shake angles (in radians)
    left_angle = 0.2
    right_angle = -0.3
    center_angle = 0.0

    for _ in range(repetitions):
        motion.setAngles("HeadYaw", left_angle, 0.2)
        time.sleep(speed)
        motion.setAngles("HeadYaw", right_angle, 0.2)
        time.sleep(speed)

    # Return head to center
    motion.setAngles("HeadYaw", center_angle, 0.2)
    time.sleep(speed)

def cross_arms_and_speak(session):
    # Get services
    global USE_LEDS

    motion = session.service("ALMotion")
    leds = session.service("ALLeds")
    tts = session.service("ALTextToSpeech")

    # Wake up the robot
    #motion.wakeUp()

    # Move to initial posture
    #posture.goToPosture("StandInit", 0.5)

    # Enable stiffness
    motion.setStiffnesses(["LArm", "RArm"], 1.0)

    shake_head(motion)

    if USE_LEDS:
        leds.fadeRGB("FaceLeds", 0xff0000, 1)  # Red alert

    # Speak the error
    tts.say("ERROR: Something went wrong")

    # Move arms
    cross_arms(motion)

    # Hold for dramatic effect
    time.sleep(2)

    if USE_LEDS:
        # leds.fadeRGB("FaceLeds", 0x000000, 0.2) # Off
        leds.fadeRGB("FaceLeds",0x111111, 1) # Neutral
        leds.setIntensity("FaceLeds", 1)

    # Return to neutral
    go_to_armrest(motion)

    # Optionally rest
    #motion.rest()


if __name__ == "__main__":
    try:
        # Replace with your robot's IP address
        robot_ip = "192.168.0.105"
        port = 9559

        app = qi.Application(["CrossArmsError", "--qi-url=tcp://{}:{}".format(robot_ip, port)])
        app.start()
        session = app.session

        cross_arms_and_speak(session)

    except Exception as e:
        print("Error connecting to the robot: ", e)
        sys.exit(1)
